#include "game.h"
#include <array>
#include <valarray>
#include <iostream>
#include <format>
#include <optional>
#include "ga.h"
#include "time.h"


int numberofpeople = 20;
int numberofgenes = 40;
static int step = 0;
Individual currIndividual;
Population totalPopulation = pop();



Individual iri()
{
    Individual initialrandomindividual;
    //int finalNum = rand() % (max - min + 1) + min; // Generate the number, assign to variable.
    ShipCommand initial;

    srand(time(NULL));
    for (int i = 0; i < numberofgenes; i++)
    {
        //int randNum = rand()%(max-min + 1) + min;
        initial.power = rand() % (4 - 0 + 1) + 0;
        initial.rotation = rand() % (60 - 0 + 1) - 30;
        initialrandomindividual.gene.push_back(initial);
    }
    return initialrandomindividual;
}

Population pop()
{
    Population population;
    for (int i = 0; i < numberofpeople; i++)
    {
        Individual individual = iri();
        population.wholePopulation.push_back(individual);
    }
    return population;
}

ShipCommand gaCMD(ShipState const& state)
{

    return currIndividual.gene.at(step++);
}

void runGA(Level gameLevel, TerrainData const* g_terrain)
{

    for (int i = 0; i < numberofpeople; i++)
    {
        currIndividual = totalPopulation.wholePopulation.at(i);
        std::vector<ShipState> sim_result = run_simulation(&gaCMD, gameLevel);
        ShipState end = sim_result.at(sim_result.size() - 1);
        std::cout << end.position.x;
        std::cout << "\n \n";
        std::cout << end.position.y;
        step = 0;
    }

}





void fittness(ShipState const& ship, Individual& currIndividual, TerrainData const* g_terrain)
{
    
    //domath
    int returnfittness = 0;

    float rotate = ship.rotation;
    std::cout << "fittness calc\n";
    currIndividual.fittness = rotate;
    std::cout << currIndividual.fittness;

    // find find flat___________________________________________
    float previous = g_terrain->m_points[0].y;
    sf::Vector2f flatvector = g_terrain->m_points[0];
    sf::Vector2f leftflat = g_terrain->m_points[0];
    sf::Vector2f rightflat = g_terrain->m_points[0];
    float middle = 0.69f;
    float middleheight = 0.69f;
    for (int i = 1; i < g_terrain->m_points.size(); i++)
    {
        if (flatvector.y == g_terrain->m_points[i].y)
        {
            middle = (flatvector.x + g_terrain->m_points[i].x) / 2;
            middleheight = flatvector.y;
            leftflat = flatvector;
            rightflat = g_terrain->m_points[i];
            std::cout << "* Debug " << middle << std::endl;
            float leftx = leftflat.x;
            float rightx = rightflat.x;
            std::cout << "* Debug left " << leftx << std::endl;
            std::cout << "* Debug " << rightx << std::endl;
        }
        else
        {
            previous = g_terrain->m_points[i].y;
            flatvector = g_terrain->m_points[i];
        }
    }

    if (ship.position.x >= leftflat.x && ship.position.x <= rightflat.x)
    {
        returnfittness = returnfittness + 10000; 
    }
    else
    {
        returnfittness = returnfittness + 333;
    }

    std::cout << "* returnfittness " << returnfittness << std::endl;
}


